<template>
  <div class="about">
    <h1>This is a demo frontend</h1>
    <p>
      ¡Hola! Si estás aquí, probablemente sea porque estás haciendo el curso de Backend con NodeJS.
      ¡Genial! Dentro de poco tendrás los conocimientos necesarios para ser un maestro de NodeJS.
      Enhorabuena.
    </p>
    <p>
      En cualquier caso, esto es una app en vue que pretende servir de front para poder probar una
      API de un chat. Además, está incorporada la tecnología de WebSockets para poder tener
      comunicación en tiempo real con el servidor. La verdad es que es un proyecto divertido.
    </p>
    <p>
      Si te surje cualquier duda, escríbeme un mail a hola@codingcarlos.com, o un mensaje por
      twitter o instagram. En todas partes soy @CodingCarlos.
    </p>
    <p>
      ¡Gracias por tu tiempo, y happy codding!
    </p>
  </div>
</template>
